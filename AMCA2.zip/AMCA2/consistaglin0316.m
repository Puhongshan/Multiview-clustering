function [ result t] = consistaglin0111( x,A,Y,alpha,beta,gamma,m,n,a,nv )
r=m; c=length(unique(Y));

for i=1:nv
 Z{i}=rand(r,n)/r;
 Z{i}=Z{i}./sum(Z{i});
 P{i}=Z{i}*Z{i}';
 P{i}=P{i}./sum(P{i});
%  P{i}=rand(m,m);
%  P{i}=P{i}./sum(P{i});
end

%    rng(5489,'twister'); %�������������
S=rand(r,n);S=S./sum(S); F=[];PZ=zeros(m,n);rev=[];flag=1;iter=0;iter1=0;maxiter=5;vs=[];
Sold=zeros(m,n);rev=[];conver=1;
  
tic
 while flag
% for l=1:maxiter
    Sold=S;
  iter=iter+1
%%%%%%%%����F
%     D1=(sum(S')).^(-1/2);
%     D2=(sum(S)).^(-1/2);
%     D=[D1,D2];
%    [~,V,U,~,~,~,]=svd2uv(S', c);       %����Z������c����������    
%     F=[U;V];                                     %����F
%    for ij=1:m
%        W1=[];
%         for ji=1:n
%             W1(ij,ji)=(norm(((F(ij,:)*D(ij)-F(m+ji,:)*D(m+ji))),'fro'))^2;  %�����W(���Ǳʼ����M)
%         end
%         W=W1;
%    end
  
 options = optimset( 'Algorithm','interior-point-convex','Display','off');
%����Z{i} 
AA=cell(1,nv);
for i=1:nv
    AA{i}=A{i}'*A{i};
end
for j=1:nv
 Z1=zeros(r,n);
 AAA=cell(1,n);
 parfor jj=1:n
 AAA{jj}=2*AA{j}-2*alpha*(S(:,jj).*P{j})'*(S(:,jj).*P{j})+2*beta*eye(r);
%  AAA{jj}(isinf(AAA{jj}))=eps;   AAA{jj}(isnan(AAA{jj}))=eps;  

%       try
 Z1(:,jj)=quadprog(AAA{jj},(-2*x{j}(:,jj)'*A{j})',[],[],ones(1,r),1,zeros(r,1),ones(r,1),[],options);
%      end
end
Z{j}=Z1;
end

 
%����S
PZ=zeros(m,n);
for i=1:nv
PZ=(P{i}*Z{i}).*(P{i}*Z{i})+PZ;
end

parfor ji=1:n
     H=-2*alpha*diag(PZ(:,ji));
     H(isnan(H))=eps;H(isinf(H))=eps;
%   S(:,ji)=quadprog(H,[],[],[],ones(1,r),1,zeros(r,1),ones(r,1),[],options);
%  try
     S(:,ji)=quadprog(H,[],[],[],ones(1,r),1,zeros(r,1),ones(r,1),[],options);
%  end
 end

% % LP��������Pv
% options = optimoptions('linprog','Algorithm','interior-point','Display','off');
% Aeq=[];
% for j=1:m
%     aeq=zeros(1,m*m);
%     aeq(m*(j-1)+1:j*m)=1;
%     Aeq=[Aeq;aeq];
% end
% for j=1:m
%     aeq=zeros(1,m*m);
%     aeq(j:m:m*m)=1;
%     Aeq=[Aeq;aeq];
% end
% for i=1:nv
% Q{i}=(Z{i}.*Z{i})*(S.*S)';
% Q{i}=Q{i}';
% Q{i}=Q{i}(:); %Q�����ı�
% end
% for i=1:nv  %LP��P���ɳ�����
% P11{i}=zeros(r*r,1);
% P11{i}=linprog(-Q{i},[],[],Aeq,ones(2*r,1),zeros(r*r,1),ones(r*r,1),[],options);
%  if size(P11{i})~=[0,0]
% P{i}=reshape(P11{i},r,r);
%  end
% end

%����Pv
 
for i=1:nv
    ep=50;index=1;a=0.5;
while ep >= 1e-6 && index <=80

    pP = P{i};        
   Q(1:r,1:r) =alpha*2*(S.*S.*(P{i}*Z{i}))*Z{i}';  
    Q = gm_dsn(Q);   
    P{i} = (1-a)*P{i}+a*Q(1:r,1:r);
    P{i} = P{i}/(max(max(P{i})));        
    ep = max(max(abs(pP-P{i})));
    index = index + 1;
end
%same as FMVACC
ap=P{i};
xp=zeros(size(ap));
for ii=1:size(ap,1)
    [~,ind] = max(ap(:,ii));
    xp(ii,ind)=1;
end
P{i}=xp;
end


if toc>3000
    flag=0;
    conver=0;
end
 if(iter>10) && ((norm(S-Sold,'fro')/norm(Sold,'fro')<1e-3) || iter>maxiter) 
flag=0;
 end
 
obj=0;
 for i=1:nv
     obj1 = norm(x{i}-A{i}*Z{i},'fro')-alpha*norm(S.*(P{i}*Z{i}),'fro')+beta*(norm(Z{i},'fro'));
        obj = obj1+obj;     
 end
 rev(iter)=obj;
 %norm(x{1}-A{1}*Z{1},'fro')-alpha*norm(S.*(P{1}*Z{1}),'fro')+beta*(norm(S,'fro')+norm(Z{1},'fro'))
  t=toc ;
 
 if conver==0
     result=zeros(1,8);
 else
  [~,V,U,~,~,~,]=svd2uv(S', c);       %����Z������c����������    
  actual_ids= litekmeans(V,c,'MaxIter', 100,'Replicates',100);  %ֻ��U��þ�����                                   
[result] = Clustering8Measure(actual_ids,double(Y));
% 
%  [~,V,U,~,~,~,]=svd2uv((P{3}*Z{3}+P{1}*Z{1}+P{2}*Z{2}+P{4}*Z{4})', c);       %����Z������c����������    
%     actual_ids= litekmeans(V,c,'MaxIter', 100,'Replicates',100);  %ֻ��U��þ�����                                   
% [result] = Clustering8Measure( actual_ids,Y);
 end
 end
save('rev.mat','rev')



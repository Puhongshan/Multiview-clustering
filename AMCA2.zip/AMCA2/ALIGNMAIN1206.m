%1206 codeby �Ѻ�ɼ for ||Xv-AvZv||-alpha*||S.*(Pv*Zv)||+beta*||Z||+gamma*tr(F'LF)
% addpath('D:\����ѧϰ\�½��ļ���\�Ķ����Ļ���\����\alignanchor');
addpath('./dataset');
addpath('./measure');
addpath('./tool');
load('bbcsport4.mat'); 
% rng(5489,'twister'); %�������������
% clf
% X=Data;
 nv=length(X);
 ran=1:116;%=randperm(169);ran = ran(1:169);
for i=1:nv
    x{i}=full(double(X{i}));%x is a dvxn matrix
%     x{i}(isnan(x{i}))=0;
%     x{i}=((x{i}'-mean(x{i}'))./max(std(x{i}'),1e-6))';
%       x{i}=(x{i}'./sum(x{i})')';
%        x{i}=x{i}./max(x{i}(:));
%      x{i}=(x{i}'./max(max(x{i}'),1e-12))';%best
%      x{i}=x{i}./max(max(x{i}(:)),1e-12);
%     x{i}=x{i}./max(max(x{i}),1e-12);
    x{i}=(x{i}./max(x{i}));
%     X1{i}=x{i};
end
[~,n]=size(x{1});
% truth=Label;
% truth=Y;
 c=length(unique(truth));
 [~,n]=size(x{1});
%     truth=Y;
Y=truth;
k=10;
c=length(unique(truth));
r=[42];m=r;%z
a=0.5;
sigma=[225];%
alpha=[80];%
 beta= [8e4];%
% alpha=[0.001, 0.01, 0.1, 1 ,10 ,100, 1000];
% beta= [10,100,1e3,1e4,1e5,1e6,1e7];
gamma=[400];
%     rng(5489,'twister'); %�������������
for an=1:length(m)
    %choose anchor
    for i=1:nv
         Dist{i} = EuDist2(x{i}',x{i}',0);
        Dist{i}= exp(-Dist{i}/sigma);
      Dist{i}= Dist{i}-eye(n);
%         Dist{i} = X1{i}'*X1{i};
      J{i}= FastSepNMF(Dist{i},m(an),0) ;%r=300-length(J);
      J{i}=sort((J{i}));
%         k=randperm(m(an));
%         J{i} = ran(J{i}(k));
%         J{i}=sort(ran(J{i}));
    end
 
    for i=1:nv
        A{i}=x{i}(:,J{i});     %sepnmfѡ������ê��
    % [~, A{i}] = litekmeans((x{i})',m(an),'MaxIter', 100,'Replicates',10); A{i}=A{i}';    %kmeansѡ������ê��
    end
   fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');

 for p=1:length(alpha)
    for q=1:length(beta)
     for h=1:length(gamma)
         
        fprintf('params:\tnumanchor=%f\talpha=%f\tbeta=%f\tgamma=%d\n',m(an), alpha(p), beta(q),gamma(h));
          
            [result t]=consistaglin0316( x,A,Y,alpha(p),beta(q),gamma(h),m(an),n,a,nv );
            result1=result([1,2,4]);
           
            fprintf('result:\t%12.6f %12.6f %12.6f %12.6f\n',[result1 t]);
            dlmwrite('Prokaryotic1129.txt',[m(an) sigma alpha(p) beta(q) result t],'-append','delimiter','\t','newline','pc');
            
     end
    end
 end
end
load('rev.mat')
plot(rev)